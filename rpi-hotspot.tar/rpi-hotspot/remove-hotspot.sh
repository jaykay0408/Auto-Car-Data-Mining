#!/bin/bash

sudo systemctl disable autohotspot

sudo rm /etc/sysctl.conf
sudo cp ./backup/sysctl.conf /etc/sysctl.conf

sudo rm /etc/dhcpcd.conf
sudo cp ./backup/dhcpcd.conf /etc/dhcpcd.conf
