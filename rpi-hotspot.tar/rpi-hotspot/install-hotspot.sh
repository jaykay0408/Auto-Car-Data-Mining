#!/bin/bash
rm ./hostapd.conf
cp ./hostapd.org ./hostapd.conf
echo "ssid=$1" >> ./hostapd.conf
echo "channel=$2" >> ./hostapd.conf

sudo apt-get update
sudo apt-get upgrade
sudo apt-get install hostapd
sudo apt-get install dnsmasq

sudo systemctl unmask hostapd
sudo systemctl disable hostapd
sudo systemctl disable dnsmasq

#sudo mv /etc/hostapd/hostapd.conf ./backup/hostapd.conf
sudo cp ./hostapd.conf /etc/hostapd/hostapd.conf

sudo mv /etc/default/hostapd ./backup/hostapd
sudo cp ./hostapd /etc/default/hostapd

sudo mv /etc/dnsmasq.conf ./backup/dnsmasq.conf
sudo cp ./dnsmasq.conf /etc/dnsmasq.conf

sudo mv /etc/sysctl.conf ./backup/sysctl.conf
sudo cp ./sysctl.conf /etc/sysctl.conf

sudo mv /etc/dhcpcd.conf ./backup/dhcpcd.conf
sudo cp ./dhcpcd.conf /etc/dhcpcd.conf

#sudo mv /etc/systemd/system/autohotspot.service ./backup/autohotspot.service
sudo cp ./autohotspot.service /etc/systemd/system/autohotspot.service

sudo systemctl enable autohotspot.service

#sudo mv /usr/bin/autohotspotN ./backup/autohotspotN
sudo cp ./autohotspotN /usr/bin/autohotspotN

sudo chmod +x /usr/bin/autohotspotN
